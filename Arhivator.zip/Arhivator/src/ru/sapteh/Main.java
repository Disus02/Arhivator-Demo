package ru.sapteh;

import java.io.*;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Введите путь: ");
        String sourcePath=reader.readLine();
        File file=new File(sourcePath);
        if (!file.exists()){
            System.out.println("\n Not found: "+sourcePath);
            System.exit(0);
        }
        if (!file.isDirectory()){
            System.out.println("\n Not found: "+sourcePath);
            System.exit(0);
        }
        ZipOutputStream zip=createZipOutputStream("temp.zip");
        String[] listFile= file.list();

        for(int i= 0; i < listFile.length; i++) {
            File f1 = new File(
                    sourcePath + File.separator + listFile[i]);

            if(f1.isFile())
            {
                addFileToZip(zip, sourcePath + File.separator,
                        listFile[i]);
            }
        }
        zip.close();




    }
    static ZipOutputStream createZipOutputStream(String path) throws IOException {
        File tempFile=new File(path);
        ZipOutputStream zip=new ZipOutputStream(new FileOutputStream(path));
        zip.setLevel(Deflater.DEFAULT_COMPRESSION);
        return zip;
    }
    static void addFileToZip(ZipOutputStream zip,String path,String nameFile) throws IOException {
        System.out.println(path+nameFile);
        ZipEntry zipEntry=new ZipEntry(nameFile);
        zip.putNextEntry(zipEntry);
        FileInputStream fileInputStream=new FileInputStream(path+nameFile);
        byte[] bytes=new byte[8000];
        int nLength;
        while (true){
            nLength=fileInputStream.read(bytes);
            if (nLength<0)
                break;
                zip.write(bytes,0,nLength);

        }
        fileInputStream.close();
        zip.closeEntry();

        long sizeFile=zipEntry.getSize();
        long sizeCompressed=zipEntry.getCompressedSize();
        long difference=100 - ((sizeCompressed * 100) / sizeFile);
        System.out.println(" " + sizeFile + " (" +
                sizeCompressed + ") " + difference + "%");
    }
}
